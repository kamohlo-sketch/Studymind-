'use client';

import { useEffect, useState } from 'react';
import type { DailyReviewContent } from '@/lib/types/database';

export function DailyReview() {
  const [review, setReview] = useState<DailyReviewContent | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Only worth fetching in the evening — the route is cheap to call since it's cached,
    // but there's no reason to generate it before there's a day to summarize.
    const hour = new Date().getHours();
    if (hour < 16) {
      setLoading(false);
      return;
    }
    fetch('/api/ai/daily-review')
      .then((r) => r.json())
      .then((data) => setReview(data.review ?? null))
      .finally(() => setLoading(false));
  }, []);

  if (loading || !review) return null;

  return (
    <section className="glass rounded-2xl p-6 space-y-4">
      <p className="font-display text-lg text-gold-400">{review.headline}</p>

      <div className="grid sm:grid-cols-2 gap-4 text-sm">
        {review.achievements.length > 0 && (
          <div>
            <h3 className="text-xs uppercase tracking-wide text-ink-500 mb-2">Achievements</h3>
            <ul className="space-y-1 text-ink-100">
              {review.achievements.map((a, i) => (
                <li key={i}>{a}</li>
              ))}
            </ul>
          </div>
        )}
        {review.missed_tasks.length > 0 && (
          <div>
            <h3 className="text-xs uppercase tracking-wide text-ink-500 mb-2">Missed today</h3>
            <ul className="space-y-1 text-ink-300">
              {review.missed_tasks.map((m, i) => (
                <li key={i}>{m}</li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {review.knowledge_gained.length > 0 && (
        <div>
          <h3 className="text-xs uppercase tracking-wide text-ink-500 mb-2">Knowledge gained</h3>
          <p className="text-sm text-ink-100">{review.knowledge_gained.join(' · ')}</p>
        </div>
      )}

      <div className="flex justify-between text-xs text-ink-500 pt-2 border-t border-obsidian-700">
        <span>Suggested bedtime: {review.suggested_bedtime}</span>
        {review.estimated_readiness_note && <span>{review.estimated_readiness_note}</span>}
      </div>
    </section>
  );
}
