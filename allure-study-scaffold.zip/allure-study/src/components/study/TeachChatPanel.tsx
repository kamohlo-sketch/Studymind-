'use client';

import { useState } from 'react';
import { Mic, MicOff, Volume2, VolumeX } from 'lucide-react';
import { useVoice } from '@/lib/voice/useVoice';

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export function TeachChatPanel({
  subjectId,
  subjectName,
  conversationId,
  onConversationStart,
}: {
  subjectId: string;
  subjectName: string;
  conversationId: string | null;
  onConversationStart: (id: string) => void;
}) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'assistant',
      content: `Let's work on ${subjectName}. Tell me what you're stuck on, say "quiz me" to start, or tap the mic and just talk to me.`,
    },
  ]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [voiceModeOn, setVoiceModeOn] = useState(false);

  const { isSupported, isListening, isSpeaking, interimTranscript, startListening, stopListening, speak, stopSpeaking } =
    useVoice((finalTranscript) => {
      send(finalTranscript);
    });

  async function send(overrideText?: string) {
    const userMessage = (overrideText ?? input).trim();
    if (!userMessage || sending) return;
    setMessages((m) => [...m, { role: 'user', content: userMessage }]);
    setInput('');
    setSending(true);

    try {
      const res = await fetch('/api/ai/teach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversationId,
          subjectId,
          subjectName,
          message: userMessage,
        }),
      });
      const data = await res.json();
      if (data.conversationId && !conversationId) onConversationStart(data.conversationId);
      const reply = data.reply ?? '…';
      setMessages((m) => [...m, { role: 'assistant', content: reply }]);
      if (voiceModeOn) speak(reply);
    } finally {
      setSending(false);
    }
  }

  function toggleMic() {
    if (isListening) stopListening();
    else {
      stopSpeaking(); // don't listen while the AI is still talking
      startListening();
    }
  }

  function toggleVoiceMode() {
    setVoiceModeOn((v) => {
      if (v) stopSpeaking();
      return !v;
    });
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
        {messages.map((m, i) => (
          <div key={i} className={m.role === 'user' ? 'text-right' : 'text-left'}>
            <div
              className={`inline-block max-w-lg rounded-2xl px-4 py-2 text-sm ${
                m.role === 'user'
                  ? 'bg-gold-500 text-obsidian-950'
                  : 'bg-obsidian-800 text-ink-100'
              }`}
            >
              {m.content}
            </div>
          </div>
        ))}
        {sending && <div className="text-ink-500 text-sm">Thinking…</div>}
        {isListening && (
          <div className="text-right">
            <div className="inline-block max-w-lg rounded-2xl px-4 py-2 text-sm bg-gold-500/20 text-gold-400 italic">
              {interimTranscript || 'Listening…'}
            </div>
          </div>
        )}
      </div>

      <div className="px-6 py-4 border-t border-obsidian-800 flex items-center gap-3">
        {isSupported && (
          <button
            onClick={toggleMic}
            title={isListening ? 'Stop listening' : 'Talk instead of typing'}
            className={`rounded-full p-3 transition-colors ${
              isListening ? 'bg-gold-500 text-obsidian-950' : 'bg-obsidian-800 text-ink-300 hover:text-gold-400'
            }`}
          >
            {isListening ? <Mic size={18} /> : <MicOff size={18} />}
          </button>
        )}

        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && send()}
          placeholder={isSupported ? 'Ask a question, or tap the mic…' : "Ask a question, or say what you're stuck on…"}
          className="flex-1 rounded-xl bg-obsidian-800 border border-obsidian-700 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-gold-500"
        />

        <button
          onClick={toggleVoiceMode}
          title={voiceModeOn ? 'Voice replies on — tap to mute' : 'Voice replies off — tap to unmute'}
          className={`rounded-full p-3 transition-colors ${
            voiceModeOn ? 'bg-gold-500 text-obsidian-950' : 'bg-obsidian-800 text-ink-300 hover:text-gold-400'
          }`}
        >
          {isSpeaking ? <Volume2 size={18} className="animate-pulse" /> : voiceModeOn ? <Volume2 size={18} /> : <VolumeX size={18} />}
        </button>

        <button
          onClick={() => send()}
          disabled={sending}
          className="rounded-xl bg-gold-500 text-obsidian-950 font-semibold px-5 py-3 disabled:opacity-50"
        >
          Send
        </button>
      </div>

      {!isSupported && (
        <p className="px-6 pb-3 text-xs text-ink-500">
          Voice input isn't supported in this browser — try Chrome or Edge for "Quiz me" by voice.
        </p>
      )}
    </div>
  );
}
