'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

interface SubjectInput {
  name: string;
  target_grade: string;
  feeling: 'struggle' | 'neutral' | 'enjoy';
}

interface ExtracurricularInput {
  title: string;
  day_of_week: number;
  start_time: string;
  end_time: string;
}

const STEPS = [
  'basics',
  'curriculum',
  'subjects',
  'schedule',
  'commute',
  'extracurriculars',
  'timetable',
  'review',
] as const;
type Step = (typeof STEPS)[number];

const DAY_LABELS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function OnboardingInterview() {
  const supabase = createClient();
  const router = useRouter();
  const [stepIndex, setStepIndex] = useState(0);
  const [saving, setSaving] = useState(false);
  const [timetableStatus, setTimetableStatus] = useState<string | null>(null);

  const [basics, setBasics] = useState({ full_name: '', preferred_name: '', grade: '' });
  const [curriculum, setCurriculum] = useState({ curriculum: 'CAPS', school_name: '' });
  const [subjects, setSubjects] = useState<SubjectInput[]>([
    { name: '', target_grade: '', feeling: 'neutral' },
  ]);
  const [schedule, setSchedule] = useState({
    school_start_time: '07:30',
    school_end_time: '14:00',
    typical_home_time: '15:00',
    typical_sleep_time: '21:30',
  });
  const [commute, setCommute] = useState({
    travel_mode: 'car',
    travel_minutes: 30,
    prep_minutes: 30,
    breakfast_minutes: 15,
  });
  const [extracurriculars, setExtracurriculars] = useState<ExtracurricularInput[]>([]);

  const step: Step = STEPS[stepIndex];

  function next() {
    setStepIndex((i) => Math.min(i + 1, STEPS.length - 1));
  }
  function back() {
    setStepIndex((i) => Math.max(i - 1, 0));
  }

  function updateSubject(i: number, patch: Partial<SubjectInput>) {
    setSubjects((s) => s.map((sub, idx) => (idx === i ? { ...sub, ...patch } : sub)));
  }

  function addExtracurricular() {
    setExtracurriculars((e) => [
      ...e,
      { title: '', day_of_week: 1, start_time: '17:00', end_time: '18:30' },
    ]);
  }

  async function handleTimetableUpload(file: File) {
    setTimetableStatus('Reading your timetable…');
    const dataUrl = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });

    const res = await fetch('/api/timetable/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ imageDataUrl: dataUrl }),
    });
    const data = await res.json();

    if (!res.ok) {
      setTimetableStatus(data.error ?? 'Could not read that image — try a clearer photo.');
      return;
    }
    setTimetableStatus(`Imported ${data.imported} classes across ${data.daysCovered.length} days.`);
  }

  async function finish() {
    setSaving(true);
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return router.push('/login');

    await supabase.from('profiles').upsert({
      id: user.id,
      full_name: basics.full_name,
      preferred_name: basics.preferred_name || basics.full_name,
      grade: basics.grade,
      curriculum: curriculum.curriculum,
      school_name: curriculum.school_name,
      school_start_time: schedule.school_start_time,
      school_end_time: schedule.school_end_time,
      typical_home_time: schedule.typical_home_time,
      typical_sleep_time: schedule.typical_sleep_time,
      travel_mode: commute.travel_mode,
      travel_minutes: commute.travel_minutes,
      prep_minutes: commute.prep_minutes,
      breakfast_minutes: commute.breakfast_minutes,
      onboarding_completed: true,
    });

    const validSubjects = subjects.filter((s) => s.name.trim());
    if (validSubjects.length > 0) {
      const { data: insertedSubjects } = await supabase
        .from('subjects')
        .insert(
          validSubjects.map((s) => ({
            user_id: user.id,
            name: s.name.trim(),
            target_grade: s.target_grade ? Number(s.target_grade) : null,
          }))
        )
        .select('id, name');

      // Feeling ("struggles with" / "enjoys") seeds the memory graph directly —
      // the AI shouldn't have to wait for behavioral evidence to know this.
      const memoryNodes = (insertedSubjects ?? []).flatMap((row) => {
        const original = validSubjects.find((s) => s.name.trim() === row.name);
        if (!original || original.feeling === 'neutral') return [];
        return [
          {
            user_id: user.id,
            subject_id: row.id,
            node_type: original.feeling === 'struggle' ? 'weak_topic' : 'strong_topic',
            label:
              original.feeling === 'struggle'
                ? `Self-reported at onboarding: finds ${row.name} difficult`
                : `Self-reported at onboarding: enjoys ${row.name}`,
            confidence: 0.6,
            evidence_count: 1,
          },
        ];
      });
      if (memoryNodes.length > 0) {
        await supabase.from('ai_memory_nodes').insert(memoryNodes);
      }
    }

    const validExtracurriculars = extracurriculars.filter((e) => e.title.trim());
    if (validExtracurriculars.length > 0) {
      await supabase.from('extracurriculars').insert(
        validExtracurriculars.map((e) => ({
          user_id: user.id,
          title: e.title.trim(),
          day_of_week: e.day_of_week,
          start_time: e.start_time,
          end_time: e.end_time,
          category: 'sport',
        }))
      );
    }

    router.push('/dashboard');
  }

  const inputClass =
    'w-full rounded-xl bg-obsidian-800 border border-obsidian-700 px-4 py-3 text-ink-100 focus:outline-none focus:ring-2 focus:ring-gold-500';
  const labelClass = 'block text-sm text-ink-500 mb-1';

  return (
    <main className="min-h-screen flex items-center justify-center px-6 py-12">
      <div className="w-full max-w-lg">
        <p className="text-xs text-ink-500 mb-2">
          Step {stepIndex + 1} of {STEPS.length}
        </p>
        <div className="h-1 w-full bg-obsidian-800 rounded-full mb-8 overflow-hidden">
          <div
            className="h-full bg-gold-500 transition-all"
            style={{ width: `${((stepIndex + 1) / STEPS.length) * 100}%` }}
          />
        </div>

        {step === 'basics' && (
          <div className="space-y-5">
            <h1 className="font-display text-2xl text-gold-400">
              Hi, I'm ALLURE. I'll organize your academic life — this takes about 5 minutes.
            </h1>
            <div>
              <label className={labelClass}>Full name</label>
              <input
                className={inputClass}
                value={basics.full_name}
                onChange={(e) => setBasics((b) => ({ ...b, full_name: e.target.value }))}
              />
            </div>
            <div>
              <label className={labelClass}>What should I call you?</label>
              <input
                className={inputClass}
                value={basics.preferred_name}
                onChange={(e) => setBasics((b) => ({ ...b, preferred_name: e.target.value }))}
              />
            </div>
            <div>
              <label className={labelClass}>Grade</label>
              <input
                className={inputClass}
                value={basics.grade}
                onChange={(e) => setBasics((b) => ({ ...b, grade: e.target.value }))}
              />
            </div>
          </div>
        )}

        {step === 'curriculum' && (
          <div className="space-y-5">
            <h2 className="font-display text-xl text-ink-100">Which curriculum and school?</h2>
            <div>
              <label className={labelClass}>Curriculum</label>
              <select
                className={inputClass}
                value={curriculum.curriculum}
                onChange={(e) => setCurriculum((c) => ({ ...c, curriculum: e.target.value }))}
              >
                {['CAPS', 'IEB', 'IB', 'AP', 'Cambridge'].map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className={labelClass}>School</label>
              <input
                className={inputClass}
                value={curriculum.school_name}
                onChange={(e) => setCurriculum((c) => ({ ...c, school_name: e.target.value }))}
              />
            </div>
          </div>
        )}

        {step === 'subjects' && (
          <div className="space-y-5">
            <h2 className="font-display text-xl text-ink-100">Your subjects</h2>
            <p className="text-ink-500 text-sm">
              Tell me how you feel about each one — this shapes how I teach from day one.
            </p>
            {subjects.map((s, i) => (
              <div key={i} className="glass rounded-xl p-4 space-y-3">
                <input
                  className={inputClass}
                  placeholder="Subject name"
                  value={s.name}
                  onChange={(e) => updateSubject(i, { name: e.target.value })}
                />
                <div className="flex gap-3">
                  <input
                    className={inputClass}
                    placeholder="Target grade %"
                    value={s.target_grade}
                    onChange={(e) => updateSubject(i, { target_grade: e.target.value })}
                  />
                  <select
                    className={inputClass}
                    value={s.feeling}
                    onChange={(e) => updateSubject(i, { feeling: e.target.value as SubjectInput['feeling'] })}
                  >
                    <option value="struggle">Struggle with it</option>
                    <option value="neutral">It's fine</option>
                    <option value="enjoy">Enjoy it</option>
                  </select>
                </div>
              </div>
            ))}
            <button
              type="button"
              onClick={() => setSubjects((s) => [...s, { name: '', target_grade: '', feeling: 'neutral' }])}
              className="text-gold-400 text-sm"
            >
              + Add another subject
            </button>
          </div>
        )}

        {step === 'schedule' && (
          <div className="space-y-5">
            <h2 className="font-display text-xl text-ink-100">Your daily rhythm</h2>
            {(
              [
                ['school_start_time', 'School starts at'],
                ['school_end_time', 'School ends at'],
                ['typical_home_time', 'Usually home by'],
                ['typical_sleep_time', 'Usually asleep by'],
              ] as const
            ).map(([key, label]) => (
              <div key={key}>
                <label className={labelClass}>{label}</label>
                <input
                  type="time"
                  className={inputClass}
                  value={schedule[key]}
                  onChange={(e) => setSchedule((s) => ({ ...s, [key]: e.target.value }))}
                />
              </div>
            ))}
          </div>
        )}

        {step === 'commute' && (
          <div className="space-y-5">
            <h2 className="font-display text-xl text-ink-100">Getting to school</h2>
            <div>
              <label className={labelClass}>How do you travel?</label>
              <select
                className={inputClass}
                value={commute.travel_mode}
                onChange={(e) => setCommute((c) => ({ ...c, travel_mode: e.target.value }))}
              >
                {['car', 'bus', 'walk', 'bike', 'train', 'lift_club'].map((m) => (
                  <option key={m} value={m}>
                    {m.replace('_', ' ')}
                  </option>
                ))}
              </select>
            </div>
            {(
              [
                ['travel_minutes', 'Travel time (minutes)'],
                ['prep_minutes', 'Time to get ready (minutes)'],
                ['breakfast_minutes', 'Breakfast time (minutes)'],
              ] as const
            ).map(([key, label]) => (
              <div key={key}>
                <label className={labelClass}>{label}</label>
                <input
                  type="number"
                  className={inputClass}
                  value={commute[key]}
                  onChange={(e) => setCommute((c) => ({ ...c, [key]: Number(e.target.value) }))}
                />
              </div>
            ))}
          </div>
        )}

        {step === 'extracurriculars' && (
          <div className="space-y-5">
            <h2 className="font-display text-xl text-ink-100">Sports and clubs</h2>
            <p className="text-ink-500 text-sm">
              So I can plan study time around them, not through them.
            </p>
            {extracurriculars.map((e, i) => (
              <div key={i} className="glass rounded-xl p-4 grid grid-cols-2 gap-3">
                <input
                  className={`${inputClass} col-span-2`}
                  placeholder="e.g. Rugby practice"
                  value={e.title}
                  onChange={(ev) =>
                    setExtracurriculars((list) =>
                      list.map((x, idx) => (idx === i ? { ...x, title: ev.target.value } : x))
                    )
                  }
                />
                <select
                  className={inputClass}
                  value={e.day_of_week}
                  onChange={(ev) =>
                    setExtracurriculars((list) =>
                      list.map((x, idx) =>
                        idx === i ? { ...x, day_of_week: Number(ev.target.value) } : x
                      )
                    )
                  }
                >
                  {DAY_LABELS.map((d, idx) => (
                    <option key={idx} value={idx}>
                      {d}
                    </option>
                  ))}
                </select>
                <input
                  type="time"
                  className={inputClass}
                  value={e.start_time}
                  onChange={(ev) =>
                    setExtracurriculars((list) =>
                      list.map((x, idx) => (idx === i ? { ...x, start_time: ev.target.value } : x))
                    )
                  }
                />
              </div>
            ))}
            <button type="button" onClick={addExtracurricular} className="text-gold-400 text-sm">
              + Add activity
            </button>
          </div>
        )}

        {step === 'timetable' && (
          <div className="space-y-5">
            <h2 className="font-display text-xl text-ink-100">Upload your class timetable</h2>
            <p className="text-ink-500 text-sm">
              A photo is enough — I'll read it and build your weekly schedule automatically.
              Optional — you can skip this and add it later.
            </p>
            <input
              type="file"
              accept="image/*"
              onChange={(e) => e.target.files?.[0] && handleTimetableUpload(e.target.files[0])}
              className="text-sm text-ink-300"
            />
            {timetableStatus && <p className="text-sm text-gold-400">{timetableStatus}</p>}
          </div>
        )}

        {step === 'review' && (
          <div className="space-y-5">
            <h2 className="font-display text-xl text-ink-100">That's everything.</h2>
            <p className="text-ink-500 text-sm">
              I'll use this to build your first morning briefing and study plan. You can change any
              of this later in Settings.
            </p>
          </div>
        )}

        <div className="flex justify-between mt-8">
          <button
            type="button"
            onClick={back}
            disabled={stepIndex === 0}
            className="text-ink-500 text-sm disabled:opacity-30"
          >
            Back
          </button>
          {step === 'review' ? (
            <button
              onClick={finish}
              disabled={saving}
              className="rounded-xl bg-gold-500 text-obsidian-950 font-semibold px-6 py-3 disabled:opacity-50"
            >
              {saving ? 'Setting up…' : 'Start'}
            </button>
          ) : (
            <button
              onClick={next}
              className="rounded-xl bg-gold-500 text-obsidian-950 font-semibold px-6 py-3"
            >
              Continue
            </button>
          )}
        </div>
      </div>
    </main>
  );
}
