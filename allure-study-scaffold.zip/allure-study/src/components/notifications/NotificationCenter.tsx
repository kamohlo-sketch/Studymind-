'use client';

import { useEffect, useState } from 'react';
import type { AppNotification } from '@/lib/types/database';

export function NotificationCenter() {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  async function refresh() {
    // Ask the engine to evaluate for new notifications, then fetch the current list.
    await fetch('/api/notifications', { method: 'POST' });
    const res = await fetch('/api/notifications');
    const data = await res.json();
    setNotifications(data.notifications ?? []);
  }

  useEffect(() => {
    refresh();
    const interval = setInterval(refresh, 5 * 60 * 1000); // re-evaluate every 5 minutes
    return () => clearInterval(interval);
  }, []);

  async function markRead(id: string) {
    setNotifications((n) => n.map((x) => (x.id === id ? { ...x, read_at: new Date().toISOString() } : x)));
    await fetch('/api/notifications', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id }),
    });
  }

  const unread = notifications.filter((n) => !n.read_at);
  if (unread.length === 0) return null;

  return (
    <div className="space-y-2">
      {unread.map((n) => (
        <div
          key={n.id}
          className="glass rounded-xl px-4 py-3 flex items-start justify-between gap-4 text-sm"
        >
          <div>
            <p className="text-ink-100 font-medium">{n.title}</p>
            <p className="text-ink-500 mt-0.5">{n.body}</p>
          </div>
          <button onClick={() => markRead(n.id)} className="text-gold-400 text-xs shrink-0">
            Dismiss
          </button>
        </div>
      ))}
    </div>
  );
}
