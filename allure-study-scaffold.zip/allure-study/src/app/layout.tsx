import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'ALLURE Study',
  description: 'Your AI academic companion.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-obsidian-950 text-ink-100 font-body antialiased">{children}</body>
    </html>
  );
}
