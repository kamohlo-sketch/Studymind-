'use client';

import { useEffect, useState } from 'react';
import type { GuardianDigest } from '@/lib/guardian/digest';

const STATUS_LABEL: Record<GuardianDigest['overall_status'], string> = {
  on_track: 'On track today',
  needs_attention: 'Hasn\u2019t studied yet today',
  no_recent_activity: 'No recent activity',
};

export default function GuardianPage({ params }: { params: { token: string } }) {
  const [digest, setDigest] = useState<GuardianDigest | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch(`/api/guardian/${params.token}`)
      .then(async (r) => {
        if (!r.ok) throw new Error((await r.json()).error ?? 'Failed to load');
        return r.json();
      })
      .then((data) => setDigest(data.digest))
      .catch((e) => setError(e.message));
  }, [params.token]);

  if (error) {
    return (
      <main className="min-h-screen flex items-center justify-center px-6 text-ink-300">
        {error}
      </main>
    );
  }

  if (!digest) {
    return <main className="min-h-screen flex items-center justify-center text-ink-500">Loading…</main>;
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="w-full max-w-md glass rounded-2xl p-6 space-y-5">
        <div>
          <p className="text-xs uppercase tracking-wide text-ink-500">ALLURE Guardian View</p>
          <h1 className="font-display text-2xl text-gold-400 mt-1">
            {STATUS_LABEL[digest.overall_status]}
          </h1>
          <p className="text-ink-300 text-sm mt-2">{digest.headline}</p>
        </div>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-ink-500">Current streak</p>
            <p className="text-ink-100 text-lg">{digest.current_streak} days</p>
          </div>
          <div>
            <p className="text-ink-500">Today's plan</p>
            <p className="text-ink-100 text-lg">
              {digest.study_plan_completed_today ? 'Started' : 'Not started'}
            </p>
          </div>
        </div>

        {digest.exams_this_week.length > 0 && (
          <div>
            <p className="text-sm text-ink-500 mb-2">Exams this week</p>
            <ul className="space-y-1 text-sm text-ink-100">
              {digest.exams_this_week.map((e, i) => (
                <li key={i}>
                  {e.subject} — {new Date(e.date).toLocaleDateString()}
                </li>
              ))}
            </ul>
          </div>
        )}

        <p className="text-xs text-ink-500 pt-2 border-t border-obsidian-700">
          This view shows high-level progress only. Conversations and private study details stay
          between your student and their companion.
        </p>
      </div>
    </main>
  );
}
