'use client';

import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';

export default function LoginPage() {
  const supabase = createClient();
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'sent' | 'error'>('idle');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: `${location.origin}/onboarding` },
    });
    setStatus(error ? 'error' : 'sent');
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <h1 className="font-display text-3xl text-gold-400 mb-2">ALLURE Study</h1>
        <p className="text-ink-500 mb-8">Your AI academic companion. Sign in to continue.</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@school.co.za"
            className="w-full rounded-xl bg-obsidian-800 border border-obsidian-700 px-4 py-3 text-ink-100 placeholder:text-ink-500 focus:outline-none focus:ring-2 focus:ring-gold-500"
          />
          <button
            type="submit"
            className="w-full rounded-xl bg-gold-500 text-obsidian-950 font-semibold py-3 hover:bg-gold-400 transition-colors"
          >
            Send magic link
          </button>
        </form>

        {status === 'sent' && (
          <p className="mt-4 text-sm text-ink-300">Check your email for a sign-in link.</p>
        )}
        {status === 'error' && (
          <p className="mt-4 text-sm text-red-400">Something went wrong. Try again.</p>
        )}
      </div>
    </main>
  );
}
