import OnboardingInterview from '@/components/onboarding/OnboardingInterview';

export default function OnboardingPage() {
  return <OnboardingInterview />;
}
