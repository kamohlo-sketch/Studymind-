import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { getMemoryContext } from '@/lib/ai/memory-engine';

export async function GET(req: Request) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const subjectId = searchParams.get('subjectId') ?? undefined;

  const nodes = await getMemoryContext(supabase, user.id, subjectId);
  return NextResponse.json({ nodes });
}
