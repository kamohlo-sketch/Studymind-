import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { z } from 'zod';

const bodySchema = z.object({ guardianEmail: z.string().email() });

export async function POST(req: Request) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const parsed = bodySchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const { data: link, error } = await supabase
    .from('guardian_links')
    .insert({ student_id: user.id, guardian_email: parsed.data.guardianEmail })
    .select('id, invite_token')
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  await supabase.from('profiles').update({ guardian_mode_enabled: true }).eq('id', user.id);

  // In production, email this link to guardianEmail rather than returning it directly.
  const inviteUrl = `${process.env.NEXT_PUBLIC_APP_URL}/guardian/${link.invite_token}`;
  return NextResponse.json({ inviteUrl });
}

export async function GET() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { data, error } = await supabase
    .from('guardian_links')
    .select('id, guardian_email, status, created_at, activated_at')
    .eq('student_id', user.id);

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ links: data });
}
