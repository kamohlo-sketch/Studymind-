import { NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabase/server';
import { generateGuardianDigest } from '@/lib/guardian/digest';

export async function GET(_req: Request, { params }: { params: { token: string } }) {
  const supabase = createServiceClient();

  const { data: link } = await supabase
    .from('guardian_links')
    .select('id, student_id, status')
    .eq('invite_token', params.token)
    .maybeSingle();

  if (!link || link.status === 'revoked') {
    return NextResponse.json({ error: 'Invalid or revoked invite link' }, { status: 404 });
  }

  if (link.status === 'pending') {
    await supabase
      .from('guardian_links')
      .update({ status: 'active', activated_at: new Date().toISOString() })
      .eq('id', link.id);
  }

  const digest = await generateGuardianDigest(supabase, link.student_id);

  const today = new Date().toISOString().slice(0, 10);
  await supabase
    .from('guardian_digests')
    .upsert(
      { guardian_link_id: link.id, digest_date: today, summary: digest },
      { onConflict: 'guardian_link_id,digest_date' }
    );

  return NextResponse.json({ digest });
}
