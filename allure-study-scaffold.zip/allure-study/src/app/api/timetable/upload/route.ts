import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { openai, CHAT_MODEL } from '@/lib/ai/openai';
import { z } from 'zod';

const DAY_NAMES = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

const entrySchema = z.object({
  subject_label: z.string(),
  day_of_week: z.number().min(0).max(6),
  start_time: z.string().regex(/^\d{2}:\d{2}$/),
  end_time: z.string().regex(/^\d{2}:\d{2}$/),
  location: z.string().nullable().optional(),
});

const extractionSchema = z.object({ entries: z.array(entrySchema) });

/**
 * Accepts a base64 image (photo of a printed/handwritten timetable) and returns
 * structured timetable entries. The client uploads directly as JSON with a data URL —
 * for large PDFs, convert to page images client-side first (see README note).
 */
export async function POST(req: Request) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const body = await req.json();
  const imageDataUrl: string | undefined = body.imageDataUrl;
  if (!imageDataUrl?.startsWith('data:image/')) {
    return NextResponse.json({ error: 'imageDataUrl must be a base64 image data URL' }, { status: 400 });
  }

  const completion = await openai.chat.completions.create({
    model: CHAT_MODEL,
    messages: [
      {
        role: 'user',
        content: [
          {
            type: 'text',
            text: `This image is a student's school timetable. Extract every class into structured
data. day_of_week is 0=Sunday..6=Saturday. Use 24-hour "HH:mm" times. If a cell spans a double
period, still emit one entry with the full start/end range. Skip breaks/lunch. Return JSON only:
{ "entries": [{ "subject_label": string, "day_of_week": number, "start_time": "HH:mm", "end_time": "HH:mm", "location": string | null }] }`,
          },
          { type: 'image_url', image_url: { url: imageDataUrl } },
        ],
      },
    ],
    response_format: { type: 'json_object' },
  });

  const raw = completion.choices[0]?.message?.content ?? '{"entries":[]}';
  const parsed = extractionSchema.safeParse(JSON.parse(raw));
  if (!parsed.success) {
    return NextResponse.json({ error: 'Could not parse timetable from image' }, { status: 422 });
  }

  const { entries } = parsed.data;
  if (entries.length === 0) {
    return NextResponse.json({ error: 'No classes detected — try a clearer photo' }, { status: 422 });
  }

  const { error } = await supabase.from('timetable_entries').insert(
    entries.map((e) => ({
      user_id: user.id,
      subject_label: e.subject_label,
      day_of_week: e.day_of_week,
      start_time: e.start_time,
      end_time: e.end_time,
      location: e.location ?? null,
      source: 'photo_upload' as const,
    }))
  );

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  return NextResponse.json({
    imported: entries.length,
    daysCovered: [...new Set(entries.map((e) => DAY_NAMES[e.day_of_week]))],
  });
}
