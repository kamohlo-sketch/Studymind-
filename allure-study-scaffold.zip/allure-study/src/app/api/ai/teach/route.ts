import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { openai, CHAT_MODEL } from '@/lib/ai/openai';
import { getMemoryContext, extractAndWriteMemory } from '@/lib/ai/memory-engine';
import { buildTeachingSystemPrompt, formatMemoryContext } from '@/lib/ai/prompts';
import { z } from 'zod';

const bodySchema = z.object({
  conversationId: z.string().uuid().nullable(),
  subjectId: z.string().uuid(),
  subjectName: z.string().min(1),
  message: z.string().min(1).max(4000),
});

export async function POST(req: Request) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const parsed = bodySchema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const { subjectId, subjectName, message } = parsed.data;
  let { conversationId } = parsed.data;

  if (!conversationId) {
    const { data: conversation, error } = await supabase
      .from('conversations')
      .insert({ user_id: user.id, subject_id: subjectId, mode: 'teach' })
      .select('id')
      .single();
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    conversationId = conversation.id;
  }

  await supabase.from('messages').insert({
    conversation_id: conversationId,
    role: 'user',
    content: message,
  });

  const { data: history } = await supabase
    .from('messages')
    .select('role, content')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: true })
    .limit(40);

  const memoryNodes = await getMemoryContext(supabase, user.id, subjectId);

  const completion = await openai.chat.completions.create({
    model: CHAT_MODEL,
    messages: [
      {
        role: 'system',
        content: buildTeachingSystemPrompt(subjectName, formatMemoryContext(memoryNodes)),
      },
      ...(history ?? []).map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content })),
    ],
  });

  const reply = completion.choices[0]?.message?.content ?? '';

  await supabase.from('messages').insert({
    conversation_id: conversationId,
    role: 'assistant',
    content: reply,
  });

  extractAndWriteMemory(
    supabase,
    user.id,
    `[Teach mode: ${subjectName}] Student said: "${message}"\nAI replied: "${reply}"`,
    subjectId
  ).catch((err) => console.error('memory extraction failed', err));

  return NextResponse.json({ conversationId, reply });
}
