import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { openai, CHAT_MODEL } from '@/lib/ai/openai';
import { getMemoryContext } from '@/lib/ai/memory-engine';
import { buildBriefingPrompt, formatMemoryContext } from '@/lib/ai/prompts';
import type { DailyBriefingContent } from '@/lib/types/database';

export async function GET() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const today = new Date().toISOString().slice(0, 10);

  // Serve the cached briefing if one was already generated today.
  const { data: cached } = await supabase
    .from('daily_briefings')
    .select('content')
    .eq('user_id', user.id)
    .eq('briefing_date', today)
    .maybeSingle();

  if (cached) {
    return NextResponse.json({ briefing: cached.content });
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single();

  if (!profile) {
    return NextResponse.json({ error: 'Profile not found — complete onboarding first' }, { status: 400 });
  }

  const [memoryNodes, { data: assignments }, { data: exams }] = await Promise.all([
    getMemoryContext(supabase, user.id),
    supabase
      .from('assignments')
      .select('title, due_at, subject_id, estimated_minutes')
      .eq('user_id', user.id)
      .neq('status', 'done')
      .lte('due_at', new Date(Date.now() + 7 * 86400000).toISOString()),
    supabase
      .from('exams')
      .select('title, exam_date, readiness_score')
      .eq('user_id', user.id)
      .gte('exam_date', new Date().toISOString()),
  ]);

  const scheduleFacts = `
Assignments due in the next 7 days: ${JSON.stringify(assignments ?? [])}
Upcoming exams: ${JSON.stringify(exams ?? [])}
School hours: ${profile.school_start_time ?? 'unknown'}-${profile.school_end_time ?? 'unknown'}
Typical home time: ${profile.typical_home_time ?? 'unknown'}
`.trim();

  const completion = await openai.chat.completions.create({
    model: CHAT_MODEL,
    messages: [
      {
        role: 'user',
        content: buildBriefingPrompt(profile, formatMemoryContext(memoryNodes), scheduleFacts),
      },
    ],
    response_format: { type: 'json_object' },
  });

  const content = JSON.parse(
    completion.choices[0]?.message?.content ?? '{}'
  ) as DailyBriefingContent;

  await supabase.from('daily_briefings').insert({
    user_id: user.id,
    briefing_date: today,
    content,
  });

  return NextResponse.json({ briefing: content });
}
