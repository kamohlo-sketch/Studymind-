import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { openai, CHAT_MODEL } from '@/lib/ai/openai';
import { getMemoryContext } from '@/lib/ai/memory-engine';
import { buildDailyReviewPrompt, formatMemoryContext } from '@/lib/ai/prompts';
import type { DailyReviewContent } from '@/lib/types/database';

export async function GET() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const today = new Date().toISOString().slice(0, 10);

  const { data: cached } = await supabase
    .from('daily_reviews')
    .select('content')
    .eq('user_id', user.id)
    .eq('review_date', today)
    .maybeSingle();

  if (cached) return NextResponse.json({ review: cached.content });

  const { data: profile } = await supabase.from('profiles').select('*').eq('id', user.id).single();
  if (!profile) {
    return NextResponse.json({ error: 'Profile not found' }, { status: 400 });
  }

  const [memoryNodes, { data: assignments }, { data: sessions }] = await Promise.all([
    getMemoryContext(supabase, user.id),
    supabase
      .from('assignments')
      .select('title, status, due_at')
      .eq('user_id', user.id)
      .lte('due_at', `${today}T23:59:59`),
    supabase
      .from('study_sessions')
      .select('topic, subject_id, planned_minutes, actual_minutes, accuracy')
      .eq('user_id', user.id)
      .gte('started_at', `${today}T00:00:00`),
  ]);

  const dayFacts = `
Assignments due today or earlier: ${JSON.stringify(assignments ?? [])}
Study sessions completed today: ${JSON.stringify(sessions ?? [])}
Usual sleep time: ${profile.typical_sleep_time ?? 'unknown'}
`.trim();

  const completion = await openai.chat.completions.create({
    model: CHAT_MODEL,
    messages: [
      {
        role: 'user',
        content: buildDailyReviewPrompt(profile, formatMemoryContext(memoryNodes), dayFacts),
      },
    ],
    response_format: { type: 'json_object' },
  });

  const content = JSON.parse(
    completion.choices[0]?.message?.content ?? '{}'
  ) as DailyReviewContent;

  await supabase.from('daily_reviews').insert({
    user_id: user.id,
    review_date: today,
    content,
  });

  return NextResponse.json({ review: content });
}
