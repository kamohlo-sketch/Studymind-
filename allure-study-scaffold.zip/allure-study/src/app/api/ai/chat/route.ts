import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { openai, CHAT_MODEL } from '@/lib/ai/openai';
import { getMemoryContext, extractAndWriteMemory } from '@/lib/ai/memory-engine';
import { buildChatSystemPrompt, formatMemoryContext } from '@/lib/ai/prompts';
import { z } from 'zod';

const bodySchema = z.object({
  conversationId: z.string().uuid().nullable(),
  message: z.string().min(1).max(4000),
  subjectId: z.string().uuid().nullable().optional(),
});

export async function POST(req: Request) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const parsed = bodySchema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const { message, subjectId } = parsed.data;
  let { conversationId } = parsed.data;

  if (!conversationId) {
    const { data: conversation, error } = await supabase
      .from('conversations')
      .insert({ user_id: user.id, subject_id: subjectId ?? null, mode: 'chat' })
      .select('id')
      .single();
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    conversationId = conversation.id;
  }

  await supabase.from('messages').insert({
    conversation_id: conversationId,
    role: 'user',
    content: message,
  });

  const { data: history } = await supabase
    .from('messages')
    .select('role, content')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: true })
    .limit(30);

  const memoryNodes = await getMemoryContext(supabase, user.id, subjectId ?? undefined);

  const completion = await openai.chat.completions.create({
    model: CHAT_MODEL,
    messages: [
      { role: 'system', content: buildChatSystemPrompt(formatMemoryContext(memoryNodes)) },
      ...(history ?? []).map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content })),
    ],
  });

  const reply = completion.choices[0]?.message?.content ?? '';

  await supabase.from('messages').insert({
    conversation_id: conversationId,
    role: 'assistant',
    content: reply,
  });

  // Fire-and-forget memory extraction so the graph learns from this exchange
  // without holding up the response to the user.
  extractAndWriteMemory(
    supabase,
    user.id,
    `Student said: "${message}"\nAI replied: "${reply}"`,
    subjectId ?? undefined
  ).catch((err) => console.error('memory extraction failed', err));

  return NextResponse.json({ conversationId, reply });
}
