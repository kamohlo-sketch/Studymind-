import { NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabase/server';
import { openai, CHAT_MODEL } from '@/lib/ai/openai';
import { getMemoryContext } from '@/lib/ai/memory-engine';
import { buildBriefingPrompt, formatMemoryContext } from '@/lib/ai/prompts';

/**
 * Wire this to a scheduled trigger (Vercel Cron, Supabase Edge Function cron, etc.)
 * to run once daily, early morning, per user's timezone. Protected by CRON_SECRET
 * so it can't be hit publicly.
 */
export async function POST(req: Request) {
  const authHeader = req.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const supabase = createServiceClient();
  const today = new Date().toISOString().slice(0, 10);

  const { data: profiles, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('onboarding_completed', true);

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  let generated = 0;

  for (const profile of profiles ?? []) {
    const { data: existing } = await supabase
      .from('daily_briefings')
      .select('id')
      .eq('user_id', profile.id)
      .eq('briefing_date', today)
      .maybeSingle();
    if (existing) continue;

    const memoryNodes = await getMemoryContext(supabase, profile.id);

    const [{ data: assignments }, { data: exams }] = await Promise.all([
      supabase
        .from('assignments')
        .select('title, due_at, subject_id, estimated_minutes')
        .eq('user_id', profile.id)
        .neq('status', 'done')
        .lte('due_at', new Date(Date.now() + 7 * 86400000).toISOString()),
      supabase
        .from('exams')
        .select('title, exam_date, readiness_score')
        .eq('user_id', profile.id)
        .gte('exam_date', new Date().toISOString()),
    ]);

    const scheduleFacts = `Assignments: ${JSON.stringify(assignments ?? [])}\nExams: ${JSON.stringify(exams ?? [])}`;

    const completion = await openai.chat.completions.create({
      model: CHAT_MODEL,
      messages: [
        { role: 'user', content: buildBriefingPrompt(profile, formatMemoryContext(memoryNodes), scheduleFacts) },
      ],
      response_format: { type: 'json_object' },
    });

    const content = JSON.parse(completion.choices[0]?.message?.content ?? '{}');

    await supabase.from('daily_briefings').insert({
      user_id: profile.id,
      briefing_date: today,
      content,
    });
    generated += 1;
  }

  return NextResponse.json({ generated });
}
