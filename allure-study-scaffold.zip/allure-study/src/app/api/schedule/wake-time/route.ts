import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { calculateWakeTime } from '@/lib/scheduling/wake-time';
import { z } from 'zod';

export async function GET() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { data: profile } = await supabase
    .from('profiles')
    .select(
      'school_start_time, travel_minutes, prep_minutes, breakfast_minutes, wake_buffer_minutes, wake_time_override'
    )
    .eq('id', user.id)
    .single();

  if (!profile?.school_start_time) {
    return NextResponse.json(
      { error: 'School start time not set — finish onboarding first.' },
      { status: 400 }
    );
  }

  const result = calculateWakeTime({
    schoolStartTime: profile.school_start_time,
    travelMinutes: profile.travel_minutes ?? 30,
    prepMinutes: profile.prep_minutes ?? 30,
    breakfastMinutes: profile.breakfast_minutes ?? 15,
    bufferMinutes: profile.wake_buffer_minutes ?? 10,
  });

  return NextResponse.json({
    ...result,
    // If the student has previously edited their wake time, surface that instead
    // of silently overriding it — the UI decides how to present the conflict.
    userOverride: profile.wake_time_override ?? null,
  });
}

const acceptSchema = z.object({
  action: z.enum(['accept', 'edit']),
  wakeTime: z.string().regex(/^\d{2}:\d{2}$/),
});

export async function POST(req: Request) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const parsed = acceptSchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const { action, wakeTime } = parsed.data;

  await supabase
    .from('profiles')
    .update({
      typical_wake_time: wakeTime,
      wake_time_override: action === 'edit' ? wakeTime : null,
    })
    .eq('id', user.id);

  // An edit is a learning signal: the calculated suggestion didn't match reality.
  // Recorded as a routine memory node so future briefings/calculations trend toward it.
  if (action === 'edit') {
    await supabase.from('ai_memory_nodes').insert({
      user_id: user.id,
      node_type: 'routine',
      label: `Prefers waking at ${wakeTime} rather than the calculated suggestion`,
      confidence: 0.6,
      evidence_count: 1,
    });
  }

  return NextResponse.json({ ok: true });
}
