'use client';

import { useEffect, useState } from 'react';
import type { GuardianLink } from '@/lib/types/database';

export default function SettingsPage() {
  const [email, setEmail] = useState('');
  const [links, setLinks] = useState<GuardianLink[]>([]);
  const [inviteUrl, setInviteUrl] = useState<string | null>(null);
  const [sending, setSending] = useState(false);

  async function loadLinks() {
    const res = await fetch('/api/guardian/invite');
    const data = await res.json();
    setLinks(data.links ?? []);
  }

  useEffect(() => {
    loadLinks();
  }, []);

  async function sendInvite(e: React.FormEvent) {
    e.preventDefault();
    setSending(true);
    const res = await fetch('/api/guardian/invite', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ guardianEmail: email }),
    });
    const data = await res.json();
    setSending(false);
    if (res.ok) {
      setInviteUrl(data.inviteUrl);
      setEmail('');
      loadLinks();
    }
  }

  return (
    <main className="max-w-2xl mx-auto px-6 py-10 space-y-8">
      <h1 className="font-display text-2xl text-ink-100">Settings</h1>

      <section className="glass rounded-2xl p-6 space-y-4">
        <div>
          <h2 className="text-lg text-gold-400">Guardian Mode</h2>
          <p className="text-sm text-ink-500 mt-1">
            A parent or guardian can see a high-level daily summary — streak, whether today's plan
            is started, and exams coming up this week. They never see conversations or private
            study details.
          </p>
        </div>

        <form onSubmit={sendInvite} className="flex gap-3">
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="parent@email.com"
            className="flex-1 rounded-xl bg-obsidian-800 border border-obsidian-700 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-gold-500"
          />
          <button
            type="submit"
            disabled={sending}
            className="rounded-xl bg-gold-500 text-obsidian-950 font-semibold px-5 text-sm disabled:opacity-50"
          >
            Invite
          </button>
        </form>

        {inviteUrl && (
          <p className="text-xs text-ink-300">
            Share this link: <span className="text-gold-400">{inviteUrl}</span>
          </p>
        )}

        {links.length > 0 && (
          <ul className="space-y-2 pt-2 border-t border-obsidian-700 text-sm">
            {links.map((l) => (
              <li key={l.id} className="flex justify-between text-ink-300">
                <span>{l.guardian_email}</span>
                <span className="text-ink-500 capitalize">{l.status}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}
