import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { AIGreeting } from '@/components/dashboard/AIGreeting';
import { MorningBriefing } from '@/components/dashboard/MorningBriefing';
import { SubjectGrid } from '@/components/dashboard/SubjectGrid';
import { DailyReview } from '@/components/dashboard/DailyReview';
import { NotificationCenter } from '@/components/notifications/NotificationCenter';

export default async function DashboardPage() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single();

  const { data: subjects } = await supabase
    .from('subjects')
    .select('*')
    .eq('user_id', user.id);

  return (
    <main className="max-w-5xl mx-auto px-6 py-10 space-y-8">
      <AIGreeting preferredName={profile?.preferred_name ?? profile?.full_name ?? 'there'} />
      <NotificationCenter />
      <MorningBriefing />
      <SubjectGrid subjects={subjects ?? []} />
      <DailyReview />
    </main>
  );
}
