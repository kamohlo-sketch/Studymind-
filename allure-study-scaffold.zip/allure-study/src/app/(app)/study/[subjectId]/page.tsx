import { redirect, notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { StudyWorkspace } from '@/components/study/StudyWorkspace';

export default async function StudyPage({ params }: { params: { subjectId: string } }) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: subject } = await supabase
    .from('subjects')
    .select('*')
    .eq('id', params.subjectId)
    .eq('user_id', user.id)
    .single();

  if (!subject) notFound();

  return <StudyWorkspace subject={subject} />;
}
