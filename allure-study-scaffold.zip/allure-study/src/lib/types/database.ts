// This file is a hand-written starting point. Once your Supabase project exists,
// regenerate it with: npm run supabase:types

export type MemoryNodeType =
  | 'weak_topic'
  | 'strong_topic'
  | 'preference'
  | 'routine'
  | 'goal'
  | 'mistake_pattern'
  | 'milestone'
  | 'constraint';

export interface Profile {
  id: string;
  full_name: string;
  preferred_name: string | null;
  curriculum: string;
  grade: string | null;
  timezone: string;
  school_name: string | null;
  school_start_time: string | null;
  school_end_time: string | null;
  typical_home_time: string | null;
  travel_minutes: number;
  travel_mode: 'car' | 'bus' | 'walk' | 'bike' | 'train' | 'lift_club';
  prep_minutes: number;
  breakfast_minutes: number;
  wake_buffer_minutes: number;
  typical_sleep_time: string | null;
  typical_wake_time: string | null;
  wake_time_override: string | null;
  location_permission_granted: boolean;
  guardian_mode_enabled: boolean;
  onboarding_completed: boolean;
  created_at: string;
  updated_at: string;
}

export interface TimetableEntry {
  id: string;
  user_id: string;
  subject_id: string | null;
  subject_label: string;
  day_of_week: number;
  start_time: string;
  end_time: string;
  location: string | null;
  source: 'manual' | 'photo_upload' | 'pdf_upload';
  created_at: string;
}

export interface Extracurricular {
  id: string;
  user_id: string;
  title: string;
  category: 'sport' | 'club' | 'music' | 'volunteering' | 'other';
  day_of_week: number | null;
  specific_date: string | null;
  start_time: string;
  end_time: string;
  location: string | null;
  created_at: string;
}

export interface AppNotification {
  id: string;
  user_id: string;
  type:
    | 'wake_suggestion'
    | 'leave_now'
    | 'session_ready'
    | 'progress_update'
    | 'energy_recommendation'
    | 'deadline_warning'
    | 'daily_review_ready'
    | 'guardian_digest';
  title: string;
  body: string;
  payload: Record<string, unknown>;
  scheduled_for: string;
  delivered_at: string | null;
  read_at: string | null;
  created_at: string;
}

export interface GuardianLink {
  id: string;
  student_id: string;
  guardian_email: string;
  invite_token: string;
  status: 'pending' | 'active' | 'revoked';
  created_at: string;
  activated_at: string | null;
}

export interface Subject {
  id: string;
  user_id: string;
  name: string;
  color: string;
  target_grade: number | null;
  current_grade: number | null;
  created_at: string;
}

export interface Assignment {
  id: string;
  user_id: string;
  subject_id: string;
  title: string;
  due_at: string;
  status: 'pending' | 'in_progress' | 'done' | 'overdue';
  estimated_minutes: number;
  created_at: string;
}

export interface ExamRow {
  id: string;
  user_id: string;
  subject_id: string;
  title: string;
  exam_date: string;
  predicted_grade: number | null;
  readiness_score: number;
  created_at: string;
}

export interface StudySession {
  id: string;
  user_id: string;
  subject_id: string | null;
  topic: string | null;
  started_at: string;
  ended_at: string | null;
  planned_minutes: number | null;
  actual_minutes: number | null;
  accuracy: number | null;
  self_reported_energy: number | null;
  self_reported_focus: number | null;
  started_on_time: boolean | null;
  created_at: string;
}

export interface AiMemoryNode {
  id: string;
  user_id: string;
  node_type: MemoryNodeType;
  subject_id: string | null;
  label: string;
  confidence: number;
  evidence_count: number;
  last_reinforced_at: string;
  created_at: string;
}

export interface AiMemoryEdge {
  id: string;
  from_node_id: string;
  to_node_id: string;
  relationship: string;
  weight: number;
  created_at: string;
}

export interface Conversation {
  id: string;
  user_id: string;
  subject_id: string | null;
  mode: 'chat' | 'teach' | 'quiz' | 'briefing';
  title: string | null;
  created_at: string;
}

export interface Message {
  id: string;
  conversation_id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  created_at: string;
}

export interface DailyBriefingContent {
  greeting: string;
  quote: string;
  free_time_minutes: number;
  priorities: Array<{
    subject: string;
    reason: string;
    recommended_minutes: number;
  }>;
  schedule: Array<{
    start: string;
    end: string;
    label: string;
  }>;
}

export interface DailyReviewContent {
  headline: string;
  achievements: string[];
  missed_tasks: string[];
  knowledge_gained: string[];
  estimated_readiness_note: string;
  suggested_bedtime: string;
  tomorrow_priorities: Array<{ subject: string; reason: string }>;
}

// Minimal Database shape so @supabase/ssr generics resolve.
// Replace with the generated version once you've linked a real project.
export interface Database {
  public: {
    Tables: {
      profiles: { Row: Profile; Insert: Partial<Profile>; Update: Partial<Profile> };
      subjects: { Row: Subject; Insert: Partial<Subject>; Update: Partial<Subject> };
      assignments: { Row: Assignment; Insert: Partial<Assignment>; Update: Partial<Assignment> };
      exams: { Row: ExamRow; Insert: Partial<ExamRow>; Update: Partial<ExamRow> };
      study_sessions: { Row: StudySession; Insert: Partial<StudySession>; Update: Partial<StudySession> };
      ai_memory_nodes: { Row: AiMemoryNode; Insert: Partial<AiMemoryNode>; Update: Partial<AiMemoryNode> };
      ai_memory_edges: { Row: AiMemoryEdge; Insert: Partial<AiMemoryEdge>; Update: Partial<AiMemoryEdge> };
      conversations: { Row: Conversation; Insert: Partial<Conversation>; Update: Partial<Conversation> };
      messages: { Row: Message; Insert: Partial<Message>; Update: Partial<Message> };
      timetable_entries: { Row: TimetableEntry; Insert: Partial<TimetableEntry>; Update: Partial<TimetableEntry> };
      extracurriculars: { Row: Extracurricular; Insert: Partial<Extracurricular>; Update: Partial<Extracurricular> };
      notifications: { Row: AppNotification; Insert: Partial<AppNotification>; Update: Partial<AppNotification> };
      guardian_links: { Row: GuardianLink; Insert: Partial<GuardianLink>; Update: Partial<GuardianLink> };
    };
  };
}
