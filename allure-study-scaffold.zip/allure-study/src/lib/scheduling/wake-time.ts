export interface WakeTimeInputs {
  schoolStartTime: string; // "HH:mm"
  travelMinutes: number;
  prepMinutes: number;
  breakfastMinutes: number;
  bufferMinutes: number;
}

export interface WakeTimeResult {
  wakeTime: string; // "HH:mm"
  totalMinutesNeeded: number;
  breakdown: { label: string; minutes: number }[];
}

/**
 * Calculates the recommended wake-up time by working backwards from school start,
 * rather than asking the student to guess. This mirrors the product spec exactly:
 * school start - travel - getting ready - breakfast - buffer = wake time.
 */
export function calculateWakeTime(inputs: WakeTimeInputs): WakeTimeResult {
  const { schoolStartTime, travelMinutes, prepMinutes, breakfastMinutes, bufferMinutes } = inputs;

  const [startHour, startMinute] = schoolStartTime.split(':').map(Number);
  const schoolStartTotalMinutes = startHour * 60 + startMinute;

  const totalMinutesNeeded = travelMinutes + prepMinutes + breakfastMinutes + bufferMinutes;

  let wakeTotalMinutes = schoolStartTotalMinutes - totalMinutesNeeded;
  // Handle a wake time that rolls back past midnight (e.g. a very early school start).
  if (wakeTotalMinutes < 0) wakeTotalMinutes += 24 * 60;

  const wakeHour = Math.floor(wakeTotalMinutes / 60);
  const wakeMinute = wakeTotalMinutes % 60;

  return {
    wakeTime: `${String(wakeHour).padStart(2, '0')}:${String(wakeMinute).padStart(2, '0')}`,
    totalMinutesNeeded,
    breakdown: [
      { label: 'Travel to school', minutes: travelMinutes },
      { label: 'Getting ready', minutes: prepMinutes },
      { label: 'Breakfast', minutes: breakfastMinutes },
      { label: 'Buffer', minutes: bufferMinutes },
    ],
  };
}

/**
 * Estimates how much free time is left in the evening, given a home-arrival time,
 * a bedtime, fixed commitments (extracurriculars), and planned study minutes.
 * Used by both the morning briefing ("2h15m free tonight") and home-arrival notification.
 */
export function calculateFreeTimeMinutes(params: {
  homeArrivalTime: string; // "HH:mm"
  bedtime: string; // "HH:mm"
  fixedCommitmentMinutes: number; // extracurriculars, dinner, etc. already accounted for
  plannedStudyMinutes: number;
}): number {
  const toMinutes = (t: string) => {
    const [h, m] = t.split(':').map(Number);
    return h * 60 + m;
  };

  let windowMinutes = toMinutes(params.bedtime) - toMinutes(params.homeArrivalTime);
  if (windowMinutes < 0) windowMinutes += 24 * 60;

  return Math.max(0, windowMinutes - params.fixedCommitmentMinutes - params.plannedStudyMinutes);
}
