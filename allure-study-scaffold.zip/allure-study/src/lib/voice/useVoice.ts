'use client';

import { useCallback, useEffect, useRef, useState } from 'react';

// The Web Speech API's SpeechRecognition isn't in TS's lib.dom yet in most setups —
// declare the minimal shape actually used here rather than pulling in a heavy @types package.
interface SpeechRecognitionResultEvent extends Event {
  results: {
    [index: number]: { [index: number]: { transcript: string }; isFinal: boolean };
    length: number;
  };
  resultIndex: number;
}

interface SpeechRecognitionLike extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onresult: ((event: SpeechRecognitionResultEvent) => void) | null;
  onerror: ((event: Event) => void) | null;
  onend: (() => void) | null;
}

declare global {
  interface Window {
    SpeechRecognition?: new () => SpeechRecognitionLike;
    webkitSpeechRecognition?: new () => SpeechRecognitionLike;
  }
}

export interface UseVoiceResult {
  isSupported: boolean;
  isListening: boolean;
  isSpeaking: boolean;
  interimTranscript: string;
  /** Starts listening; resolves the final transcript through onFinalTranscript. */
  startListening: () => void;
  stopListening: () => void;
  /** Speaks text aloud using the browser's TTS voice. */
  speak: (text: string) => void;
  stopSpeaking: () => void;
}

/**
 * Voice mode for the AI Tutor: "Quiz me", "Explain it differently", "I only have
 * 20 minutes" — captured as speech, sent through the same /api/ai/teach and
 * /api/ai/chat routes as typed messages, with replies read back aloud.
 *
 * Uses the browser's built-in Web Speech API — no extra service or API key needed.
 * Falls back gracefully (isSupported=false) on browsers without SpeechRecognition
 * (notably Firefox and most non-Chromium browsers as of this writing).
 */
export function useVoice(onFinalTranscript: (text: string) => void): UseVoiceResult {
  const [isSupported, setIsSupported] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [interimTranscript, setInterimTranscript] = useState('');
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const onFinalTranscriptRef = useRef(onFinalTranscript);
  onFinalTranscriptRef.current = onFinalTranscript;

  useEffect(() => {
    const SpeechRecognitionCtor =
      typeof window !== 'undefined' ? window.SpeechRecognition ?? window.webkitSpeechRecognition : undefined;

    if (!SpeechRecognitionCtor) {
      setIsSupported(false);
      return;
    }
    setIsSupported(true);

    const recognition = new SpeechRecognitionCtor();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = 'en-ZA';

    recognition.onresult = (event: SpeechRecognitionResultEvent) => {
      let interim = '';
      let final = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        const text = result[0].transcript;
        if (result.isFinal) final += text;
        else interim += text;
      }
      setInterimTranscript(interim);
      if (final.trim()) {
        onFinalTranscriptRef.current(final.trim());
        setInterimTranscript('');
      }
    };

    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);

    recognitionRef.current = recognition;
  }, []);

  const startListening = useCallback(() => {
    if (!recognitionRef.current || isListening) return;
    setIsListening(true);
    recognitionRef.current.start();
  }, [isListening]);

  const stopListening = useCallback(() => {
    recognitionRef.current?.stop();
    setIsListening(false);
  }, []);

  const speak = useCallback((text: string) => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    window.speechSynthesis.cancel(); // don't let replies queue up and talk over each other
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.02;
    utterance.pitch = 1;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  }, []);

  const stopSpeaking = useCallback(() => {
    if (typeof window !== 'undefined') window.speechSynthesis?.cancel();
    setIsSpeaking(false);
  }, []);

  return { isSupported, isListening, isSpeaking, interimTranscript, startListening, stopListening, speak, stopSpeaking };
}
