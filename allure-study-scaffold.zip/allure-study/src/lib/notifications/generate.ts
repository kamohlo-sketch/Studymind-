import type { SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '@/lib/types/database';

type TypedClient = SupabaseClient<Database>;

interface CandidateNotification {
  type: string;
  title: string;
  body: string;
  payload?: Record<string, unknown>;
  scheduledFor: Date;
}

/**
 * Evaluates the student's current state (schedule, progress, deadlines) and proposes
 * notifications worth sending. Every candidate must explain WHY, per the product spec —
 * this function's job is largely deciding what NOT to send, not what to send.
 */
export async function generateNotifications(
  supabase: TypedClient,
  userId: string
): Promise<CandidateNotification[]> {
  const candidates: CandidateNotification[] = [];
  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);

  const [{ data: assignments }, { data: extracurriculars }, { data: sessionsToday }] =
    await Promise.all([
      supabase
        .from('assignments')
        .select('title, due_at, status, estimated_minutes')
        .eq('user_id', userId)
        .neq('status', 'done'),
      supabase
        .from('extracurriculars')
        .select('title, day_of_week, start_time')
        .eq('user_id', userId),
      supabase
        .from('study_sessions')
        .select('actual_minutes, planned_minutes')
        .eq('user_id', userId)
        .gte('started_at', `${todayStr}T00:00:00`),
    ]);

  // 1. Deadline warning — only for things due within 48h that haven't been started.
  for (const a of assignments ?? []) {
    const dueAt = new Date(a.due_at);
    const hoursUntilDue = (dueAt.getTime() - now.getTime()) / 3600000;
    if (hoursUntilDue > 0 && hoursUntilDue <= 48 && a.status === 'pending') {
      candidates.push({
        type: 'deadline_warning',
        title: `${a.title} is due soon`,
        body: `Due in ${Math.round(hoursUntilDue)}h and not started yet. About ${a.estimated_minutes} minutes of work — worth starting today.`,
        scheduledFor: now,
      });
    }
  }

  // 2. Leave-now — only fires if there's an extracurricular today starting within 45 min.
  const todayDow = now.getDay();
  const upcomingActivity = (extracurriculars ?? []).find((e) => {
    if (e.day_of_week !== todayDow) return false;
    const [h, m] = e.start_time.split(':').map(Number);
    const startMinutes = h * 60 + m;
    const nowMinutes = now.getHours() * 60 + now.getMinutes();
    return startMinutes - nowMinutes > 0 && startMinutes - nowMinutes <= 45;
  });
  if (upcomingActivity) {
    candidates.push({
      type: 'leave_now',
      title: `Leaving now keeps you on schedule`,
      body: `${upcomingActivity.title} starts at ${upcomingActivity.start_time}.`,
      scheduledFor: now,
    });
  }

  // 3. Progress update — only once, only after crossing 80% of today's planned minutes.
  const plannedTotal = (sessionsToday ?? []).reduce((sum, s) => sum + (s.planned_minutes ?? 0), 0);
  const actualTotal = (sessionsToday ?? []).reduce((sum, s) => sum + (s.actual_minutes ?? 0), 0);
  if (plannedTotal > 0 && actualTotal / plannedTotal >= 0.8 && actualTotal / plannedTotal < 1) {
    candidates.push({
      type: 'progress_update',
      title: `You've finished ${Math.round((actualTotal / plannedTotal) * 100)}% of today's work`,
      body: `Almost there — one more short session and today's plan is complete.`,
      scheduledFor: now,
    });
  }

  return candidates;
}

/**
 * Writes candidate notifications, skipping anything that duplicates a notification
 * of the same type sent in the last 6 hours — this is the actual anti-spam guarantee,
 * not just a comment in the code.
 */
export async function writeNotifications(
  supabase: TypedClient,
  userId: string,
  candidates: CandidateNotification[]
) {
  const sixHoursAgo = new Date(Date.now() - 6 * 3600000).toISOString();

  const { data: recent } = await supabase
    .from('notifications')
    .select('type')
    .eq('user_id', userId)
    .gte('created_at', sixHoursAgo);

  const recentTypes = new Set((recent ?? []).map((r) => r.type));
  const toInsert = candidates.filter((c) => !recentTypes.has(c.type));

  if (toInsert.length === 0) return [];

  const { data, error } = await supabase
    .from('notifications')
    .insert(
      toInsert.map((c) => ({
        user_id: userId,
        type: c.type,
        title: c.title,
        body: c.body,
        payload: c.payload ?? {},
        scheduled_for: c.scheduledFor.toISOString(),
        delivered_at: new Date().toISOString(),
      }))
    )
    .select();

  if (error) throw error;
  return data;
}
