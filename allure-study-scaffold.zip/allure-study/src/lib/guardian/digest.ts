import type { SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '@/lib/types/database';

type TypedClient = SupabaseClient<Database>;

export interface GuardianDigest {
  overall_status: 'on_track' | 'needs_attention' | 'no_recent_activity';
  study_plan_completed_today: boolean;
  current_streak: number;
  exams_this_week: Array<{ subject: string; date: string }>;
  headline: string; // pulled from the student's own daily review headline, if one exists
}

/**
 * Deliberately narrow: this function must never select from `conversations` or
 * `messages`. That boundary is enforced here, in the one place a digest is built,
 * rather than relied on ad hoc in every caller.
 */
export async function generateGuardianDigest(
  supabase: TypedClient,
  studentId: string
): Promise<GuardianDigest> {
  const today = new Date().toISOString().slice(0, 10);
  const weekFromNow = new Date(Date.now() + 7 * 86400000).toISOString();

  const [{ data: streak }, { data: exams }, { data: review }, { data: sessionsToday }] =
    await Promise.all([
      supabase.from('streaks').select('current_streak').eq('user_id', studentId).maybeSingle(),
      supabase
        .from('exams')
        .select('title, subject_id, exam_date, subjects(name)')
        .eq('user_id', studentId)
        .gte('exam_date', today)
        .lte('exam_date', weekFromNow),
      supabase
        .from('daily_reviews')
        .select('content')
        .eq('user_id', studentId)
        .eq('review_date', today)
        .maybeSingle(),
      supabase
        .from('study_sessions')
        .select('id')
        .eq('user_id', studentId)
        .gte('started_at', `${today}T00:00:00`),
    ]);

  const currentStreak = streak?.current_streak ?? 0;
  const hasStudiedToday = (sessionsToday?.length ?? 0) > 0;

  let overallStatus: GuardianDigest['overall_status'] = 'no_recent_activity';
  if (hasStudiedToday) overallStatus = 'on_track';
  else if (currentStreak > 0) overallStatus = 'needs_attention';

  return {
    overall_status: overallStatus,
    study_plan_completed_today: hasStudiedToday,
    current_streak: currentStreak,
    exams_this_week: (exams ?? []).map((e: any) => ({
      subject: e.subjects?.name ?? 'Unknown subject',
      date: e.exam_date,
    })),
    headline:
      (review?.content as { headline?: string } | null)?.headline ??
      'No summary generated yet today.',
  };
}
