-- ALLURE Study — Migration 002
-- Smart scheduling, notifications, daily review, and guardian mode.
-- Run after schema.sql: supabase db push (or paste into the SQL editor).

-- ─────────────────────────────────────────────────────────
-- PROFILE: scheduling inputs the wake-time/notification engines need
-- ─────────────────────────────────────────────────────────
alter table profiles add column if not exists school_name text;
alter table profiles add column if not exists travel_minutes integer default 30;
alter table profiles add column if not exists travel_mode text default 'car'
  check (travel_mode in ('car', 'bus', 'walk', 'bike', 'train', 'lift_club'));
alter table profiles add column if not exists prep_minutes integer default 30;   -- getting ready
alter table profiles add column if not exists breakfast_minutes integer default 15;
alter table profiles add column if not exists wake_buffer_minutes integer default 10; -- safety margin
alter table profiles add column if not exists typical_sleep_time time default '21:30';
alter table profiles add column if not exists typical_wake_time time;            -- learned/confirmed, not calculated
alter table profiles add column if not exists wake_time_override time;          -- user edited the suggestion
alter table profiles add column if not exists location_permission_granted boolean default false;
alter table profiles add column if not exists guardian_mode_enabled boolean default false;

-- ─────────────────────────────────────────────────────────
-- TIMETABLE (weekly recurring class schedule — from onboarding or photo upload)
-- ─────────────────────────────────────────────────────────
create table if not exists timetable_entries (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references profiles(id) on delete cascade,
  subject_id uuid references subjects(id) on delete set null,
  subject_label text not null, -- raw label in case it doesn't map to a subject row yet
  day_of_week integer not null check (day_of_week between 0 and 6), -- 0 = Sunday
  start_time time not null,
  end_time time not null,
  location text,
  source text default 'manual' check (source in ('manual', 'photo_upload', 'pdf_upload')),
  created_at timestamptz default now()
);

-- ─────────────────────────────────────────────────────────
-- EXTRACURRICULARS (sport, clubs — recurring or one-off)
-- ─────────────────────────────────────────────────────────
create table if not exists extracurriculars (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references profiles(id) on delete cascade,
  title text not null,
  category text default 'other' check (category in ('sport', 'club', 'music', 'volunteering', 'other')),
  day_of_week integer check (day_of_week between 0 and 6), -- null if one-off
  specific_date date,                                       -- used when day_of_week is null
  start_time time not null,
  end_time time not null,
  location text,
  created_at timestamptz default now()
);

-- ─────────────────────────────────────────────────────────
-- NOTIFICATIONS (meaningful, explained, never spam)
-- ─────────────────────────────────────────────────────────
create table if not exists notifications (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references profiles(id) on delete cascade,
  type text not null check (type in (
    'wake_suggestion', 'leave_now', 'session_ready', 'progress_update',
    'energy_recommendation', 'deadline_warning', 'daily_review_ready', 'guardian_digest'
  )),
  title text not null,
  body text not null,       -- always includes the "why", per product spec
  payload jsonb default '{}',
  scheduled_for timestamptz not null,
  delivered_at timestamptz,
  read_at timestamptz,
  created_at timestamptz default now()
);

create index if not exists idx_notifications_user_scheduled
  on notifications(user_id, scheduled_for);

-- ─────────────────────────────────────────────────────────
-- DAILY REVIEWS (evening summary, one per day, cached like the morning briefing)
-- ─────────────────────────────────────────────────────────
create table if not exists daily_reviews (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references profiles(id) on delete cascade,
  review_date date not null,
  content jsonb not null, -- achievements, missed_tasks, knowledge_gained, readiness, suggested_bedtime, tomorrow_priorities
  created_at timestamptz default now(),
  unique (user_id, review_date)
);

-- ─────────────────────────────────────────────────────────
-- GUARDIAN MODE
-- Guardians see high-level digests only — never conversations or private chats.
-- ─────────────────────────────────────────────────────────
create table if not exists guardian_links (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid references profiles(id) on delete cascade,
  guardian_email text not null,
  invite_token uuid default uuid_generate_v4(),
  status text default 'pending' check (status in ('pending', 'active', 'revoked')),
  created_at timestamptz default now(),
  activated_at timestamptz
);

create table if not exists guardian_digests (
  id uuid primary key default uuid_generate_v4(),
  guardian_link_id uuid references guardian_links(id) on delete cascade,
  digest_date date not null,
  -- Deliberately high-level only: study_plan_completed, exams_this_week, streak,
  -- overall_status. Never message content, never per-topic detail.
  summary jsonb not null,
  created_at timestamptz default now(),
  unique (guardian_link_id, digest_date)
);

-- ─────────────────────────────────────────────────────────
-- ROW LEVEL SECURITY
-- ─────────────────────────────────────────────────────────
alter table timetable_entries enable row level security;
alter table extracurriculars enable row level security;
alter table notifications enable row level security;
alter table daily_reviews enable row level security;
alter table guardian_links enable row level security;
alter table guardian_digests enable row level security;

create policy "own timetable" on timetable_entries for all using (auth.uid() = user_id);
create policy "own extracurriculars" on extracurriculars for all using (auth.uid() = user_id);
create policy "own notifications" on notifications for all using (auth.uid() = user_id);
create policy "own daily reviews" on daily_reviews for all using (auth.uid() = user_id);
create policy "own guardian links" on guardian_links for all using (auth.uid() = student_id);

-- Guardian digests are read via a token-based server route (see /api/guardian/[token]),
-- which uses the service-role client and never exposes this table to anon/browser clients.
-- No public RLS policy is granted on guardian_digests for that reason.
